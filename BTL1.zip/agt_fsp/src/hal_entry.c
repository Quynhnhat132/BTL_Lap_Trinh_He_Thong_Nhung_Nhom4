#include <stdint.h>
#include "hal_data.h"

#define MSTP_BASE      0x40040000UL
#define AGT0_BASE      0x40084000UL
#define PORT6_BASE     0x4008C400UL
#define MSTPCRD        (*(volatile uint32_t *)(MSTP_BASE + 0x08))
#define AGTCR          (*(volatile uint8_t  *)(AGT0_BASE + 0x00))
#define AGTMR1         (*(volatile uint8_t  *)(AGT0_BASE + 0x04))
#define AGTMR2         (*(volatile uint8_t  *)(AGT0_BASE + 0x05))
#define AGTC           (*(volatile uint16_t *)(AGT0_BASE + 0x0C))
#define AGT0_IRQn   (IRQn_Type)28
#define PDR6           (*(volatile uint8_t *)(PORT6_BASE + 0x00))
#define PODR6          (*(volatile uint8_t *)(PORT6_BASE + 0x14))
#define LED_PIN        (1 << 1)

void gpio_init(void)
{
    PDR6  |= LED_PIN;
    PODR6 &= ~LED_PIN;
}

void agt0_init(void)
{
    MSTPCRD &= ~(1UL << 3);
    AGTCR = 0x00;
    AGTMR1 = (1 << 3);
    AGTMR2 = 0x00;
    AGTC = 0xFFFF;
    AGTCR |= (1 << 5);
    NVIC_EnableIRQ(AGT0_IRQn);
    AGTCR |= (1 << 7);
}

void AGT0_IRQHandler(void)
{
    AGTCR &= ~(1 << 4);
    PODR6 ^= LED_PIN;
}

void hal_entry(void)
{
    gpio_init();
    agt0_init();

    while (1)
    {
        __WFI();
    }
}
