#include "hal_data.h"

#define BLINK_PERIOD_MS 1000

volatile uint32_t ms_counter = 0;
volatile uint8_t  led_toggle_flag = 0;

void timer_callback(timer_callback_args_t * p_args)
{
    (void)p_args;

    ms_counter++;

    if (ms_counter >= BLINK_PERIOD_MS)
    {
        ms_counter = 0;
        led_toggle_flag = 1;
    }
}

void hal_entry(void)
{
    R_BSP_PinAccessEnable();
    R_BSP_PinCfg(BSP_IO_PORT_06_PIN_01, BSP_IO_DIRECTION_OUTPUT);
    R_BSP_PinWrite(BSP_IO_PORT_06_PIN_01, BSP_IO_LEVEL_LOW);

    g_timer0.p_api->open(g_timer0.p_ctrl, g_timer0.p_cfg);
    g_timer0.p_api->start(g_timer0.p_ctrl);

    while (1)
    {
        if (led_toggle_flag)
        {
            led_toggle_flag = 0;
            R_PORT6->PODR_b.PODR1 ^= 1;
        }
    }
}

