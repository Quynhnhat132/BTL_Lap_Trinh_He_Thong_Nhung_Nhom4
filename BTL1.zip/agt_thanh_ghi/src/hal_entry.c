#include "hal_data.h"

#define BLINK_PERIOD_MS 500

volatile uint32_t ms_counter = 0;
volatile uint8_t  led_toggle_flag = 0;

#define LED_PIN BSP_IO_PORT_06_PIN_01

void agt0_callback(timer_callback_args_t * p_args)
{
    (void)p_args;
    ms_counter++;

    if (ms_counter >= BLINK_PERIOD_MS)
    {
        ms_counter = 0;
        led_toggle_flag = 1;
    }
}
void hal_entry(void)
{
    R_BSP_PinAccessEnable();
    R_BSP_PinCfg(LED_PIN, BSP_IO_DIRECTION_OUTPUT);
    R_BSP_PinWrite(LED_PIN, (bsp_io_level_t)BSP_IO_LEVEL_LOW);

    g_timer0.p_api->open(g_timer0.p_ctrl, g_timer0.p_cfg);
    g_timer0.p_api->start(g_timer0.p_ctrl);

    while (1)
    {
        if (led_toggle_flag)
        {
            led_toggle_flag = 0;

            // Đảo trạng thái LED
            bsp_io_level_t current = (bsp_io_level_t)R_BSP_PinRead(LED_PIN);
            bsp_io_level_t next = (current == BSP_IO_LEVEL_LOW) ? BSP_IO_LEVEL_HIGH : BSP_IO_LEVEL_LOW;
            R_BSP_PinWrite(LED_PIN, next);
        }
    }
}
