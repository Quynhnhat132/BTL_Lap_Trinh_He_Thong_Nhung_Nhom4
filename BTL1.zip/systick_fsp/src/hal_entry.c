#include <stdint.h>
#include "hal_data.h"

#define SYST_CSR   (*(volatile uint32_t*)0xE000E010)
#define SYST_RVR   (*(volatile uint32_t*)0xE000E014)
#define SYST_CVR   (*(volatile uint32_t*)0xE000E018)
#define BLINK_PERIOD_MS   500

volatile uint32_t ms_counter = 0;
volatile uint8_t  led_toggle_flag = 0;

void systick_init_1ms(void)
{
    uint32_t ticks = SystemCoreClock / 1000;

    SYST_RVR = ticks - 1;
    SYST_CVR = 0;

    SYST_CSR = (1 << 2) |
               (1 << 1) |
               (1 << 0);
}

void SysTick_Handler(void)
{
    ms_counter++;

    if (ms_counter >= BLINK_PERIOD_MS)
    {
        ms_counter = 0;
        led_toggle_flag = 1;
    }
}

void hal_entry(void)
{
    R_PORT6->PDR_b.PDR1 = 1;
    R_PORT6->PODR_b.PODR1 = 0;
    systick_init_1ms();

    while (1)
    {
        if (led_toggle_flag)
        {
            R_PORT6->PODR_b.PODR1 ^= 1;
            led_toggle_flag = 0;
        }
    }
}
